<?php 

	/*
	* Created by Abdul Kuddus
	* website: www.simplifiedcoding.net 
	*/
	
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('DB_NAME', 'android');